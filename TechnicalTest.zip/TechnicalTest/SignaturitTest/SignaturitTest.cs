using TechnicalTest;

namespace SignaturitTest
{
    [TestClass]
    public class SignaturitTest
    {
        [TestMethod]
        public void CheckDataTest()
        {
            // Arrange
            string[] documents = { "KNV", "vs", "NNV" };
            bool expected = true;

            // Act
            var actual = Signaturit.CheckData(documents);

            // Assert
            Assert.AreEqual(expected, actual, "Wrong format.");
        }

        [TestMethod]
        public void CheckCharactersTest()
        {
            // Arrange
            string document = "KNV";
            bool expected = true;

            // Act
            var actual = Signaturit.CheckCharacters(document);

            // Assert
            Assert.AreEqual(expected, actual, "Wrong characters.");
        }

        [TestMethod]
        public void AddPointsTest()
        {
            // Arrange
            string document = "KNV";
            int expected = 7;

            // Act
            var actual = Signaturit.AddPoints(document);

            // Assert
            Assert.AreEqual(expected, actual, "Wrong result.");
        }
    }
}