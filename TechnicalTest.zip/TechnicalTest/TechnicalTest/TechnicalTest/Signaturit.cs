﻿using SignaturitLogic;

namespace TechnicalTest
{
    public class Signaturit
    {
        public Signaturit() { }

        public static void Main()
        {
            string[] documents;
            var count = 0;
            do
            {
                Console.WriteLine("Insert a combination:\n" +
                    "K -> 5 points\n" +
                    "N -> 2 points\n" +
                    "V -> 1 point\n" +
                    "# -> The value of # will be determined, so that the signature which includes it wins.\n" +
                    "E.g.: 'KNV vs NNV' or 'K#V vs NNV'");

                var combination = Console.ReadLine();
                
                //Guardamos en una variable contador las veces que aparece el caracter # para validarlo más adelante
                foreach (var comb in combination)
                {
                    if (comb.Equals('#'))
                        count++;
                }

                documents = combination.Split(' ');

            } while (!SignaturitLogicBack.CheckData(documents, count));

            SignaturitLogicBack.Solution(documents);

            Console.Write("\nPress any key to exit...");
            Console.ReadKey(true);
        }        
    }
}