using SignaturitLogic;

namespace SignaturitTest
{
    [TestClass]
    public class SignaturitTest
    {
        [TestMethod]
        public void CheckDataTest()
        {
            // Arrange
            string combination = "K#V vs NNV"; //KNV vs NNV
            string[] documents = combination.Split(' ');
            int count = 0;
            foreach (var comb in combination)
            {
                if (comb.Equals('#'))
                    count++;
            }
            bool expected = true;

            // Act
            var actual = SignaturitLogicBack.CheckData(documents, count);

            // Assert
            Assert.AreEqual(expected, actual, "Wrong format.");
        }

        [TestMethod]
        public void CheckCharactersTest()
        {
            // Arrange
            string document = "KNV"; //K#V
            bool expected = true;

            // Act
            var actual = SignaturitLogicBack.CheckCharacters(document);

            // Assert
            Assert.AreEqual(expected, actual, "Wrong characters.");
        }

        [TestMethod]
        public void AddPointsTest()
        {
            // Arrange
            string document = "KNV";
            int expected = 7;

            // Act
            var actual = SignaturitLogicBack.AddPoints(document);

            // Assert
            Assert.AreEqual(expected, actual, "Wrong result.");
        }

        [TestMethod]
        public void ChangeCharacterTest()
        {
            // Arrange
            string document = "K#V";
            int sum = 7;
            string expected = "K";

            // Act
            var actual = SignaturitLogicBack.ChangeCharacter(document, sum);

            // Assert
            Assert.AreEqual(expected, actual, "Wrong result.");
        }
    }
}