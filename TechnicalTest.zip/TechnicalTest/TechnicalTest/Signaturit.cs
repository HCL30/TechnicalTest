﻿

namespace TechnicalTest
{
    public class Signaturit
    {
        public Signaturit() { }

        static Dictionary<char, int> values = new Dictionary<char, int>{
            { 'K', 5 },
            { 'N', 2 },
            { 'V', 1 }
        };

        public static void Main()
        {
            string[] documents;
            bool validCharacters = true;
            do
            {
                Console.WriteLine("Insert a combination:\n" +
                    "·K -> 5 points\n" +
                    "·N -> 2 points\n" +
                    "·V -> 1 point\n" +
                    "E.g.: KNV vs NNV");

                var combination = Console.ReadLine();
                documents = combination.Split(' ');

                validCharacters = CheckData(documents);

            } while (documents.Length != 3 || !validCharacters || documents[1] != "vs" && documents[1] != "VS");

            var additionFirstDoc = AddPoints(documents[0]);
            var additionSecondDoc = AddPoints(documents[2]);

            if (additionFirstDoc == additionSecondDoc)
            {
                Console.WriteLine("Both documents add the same values.");
            }
            else if (additionFirstDoc > additionSecondDoc)
            {
                Console.WriteLine("The winner is: " + documents[0]);
            }
            else
            {
                Console.WriteLine("The winner is: " + documents[2]);
            }

            Console.Write("\nPress any key to exit...");
            Console.ReadKey(true);
        }

        public static bool CheckData(string[] documents)
        {
            var isValid = false;
            if (documents.Length != 3 || documents[1] != "vs" && documents[1] != "VS")
            {
                Console.WriteLine("Wrong format.\n");
                isValid = false;
            }
            else
                isValid = CheckCharacters(documents[0]) ? CheckCharacters(documents[2]) ? true : false : false;

            return isValid;
        }

        public static bool CheckCharacters(string document)
        {
            for (int i = 0; i < document.Length; i++)
            {
                var doc = Char.ToUpper(document[i]);
                if (doc != 'K' && doc != 'N' && doc != 'V')
                {
                    Console.WriteLine("Wrong characters.\n");
                    return false;
                }
            }
            return true;
        }

        public static int AddPoints(string document)
        {
            var suma = 0;
            document = document.ToUpper();
            if (document.Contains("K"))
                document = document.Replace("V", String.Empty);

            for (int i = 0; i < document.Length; i++)
                suma += values[document[i]];

            return suma;
        }

    }
}