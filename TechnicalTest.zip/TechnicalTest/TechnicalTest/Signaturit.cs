﻿

namespace TechnicalTest
{
    public class Signaturit
    {
        public Signaturit() { }

        static Dictionary<char, int> values = new Dictionary<char, int>{
            { 'K', 5 },
            { 'N', 2 },
            { 'V', 1 },
            { '#', 0 }
        };

        public static void Main()
        {
            string[] documents;
            var count = 0;
            do
            {
                Console.WriteLine("Insert a combination:\n" +
                    "K -> 5 points\n" +
                    "N -> 2 points\n" +
                    "V -> 1 point\n" +
                    "# -> The value of # will be determined, so that the signature which includes it wins.\n" +
                    "E.g.: 'KNV vs NNV' or 'K#V vs NNV'");

                var combination = Console.ReadLine();
                
                //Guardamos en una variable contador las veces que aparece el caracter # para validarlo más adelante
                foreach (var comb in combination)
                {
                    if (comb.Equals('#'))
                        count++;
                }

                documents = combination.Split(' ');

            } while (!CheckData(documents, count));

            int additionFirstDoc;
            int additionSecondDoc;

            if (documents[0].Contains("#")) //En caso de que el primer documento tenga #
            {
                //Sumamos el documento que NO contiene #
                additionSecondDoc = AddPoints(documents[2]);
                //Llamamos al método que obtiene el caracter requerido
                var character = ChangeCharacter(documents[0], additionSecondDoc);
                //Mostramos la firma correspondiente para ganar
                if (!String.IsNullOrEmpty(character))
                    Console.WriteLine(String.Format("The # should be {0} to win. The corresponding signature would be {1}.", character, documents[0].Replace("#", character).ToUpper()));
            }
            else if (documents[2].Contains("#")) //En caso de que el segundo documento tenga #
            {
                //Sumamos el documento que NO contiene #
                additionFirstDoc = AddPoints(documents[0]);
                //Llamamos al método que obtiene el caracter requerido
                var character = ChangeCharacter(documents[2], additionFirstDoc);
                //Mostramos la firma correspondiente para ganar
                if (!String.IsNullOrEmpty(character))
                    Console.WriteLine(String.Format("The # should be {0} to win. The corresponding signature would be {1}.", character, documents[2].Replace("#", character).ToUpper()));
            }
            else //Si no contienen el caracter #
            {
                //Sumamos los puntos de cada documento
                additionFirstDoc = AddPoints(documents[0]);
                additionSecondDoc = AddPoints(documents[2]);

                //Mostramos al ganador
                if (additionFirstDoc == additionSecondDoc)
                    Console.WriteLine("Both documents add the same values.");
                else if (additionFirstDoc > additionSecondDoc)
                    Console.WriteLine(String.Format("The winner is: {0}.", documents[0]).ToUpper());
                else
                    Console.WriteLine(String.Format("The winner is: {0}.", documents[2].ToUpper()));
            }

            Console.Write("\nPress any key to exit...");
            Console.ReadKey(true);
        }

        /// <summary>
        /// Método para la validación de los datos
        /// </summary>
        /// <param name="documents"></param>
        /// <param name="count"></param>
        /// <returns>Devuelve un bool para saber si todo es correcto o no</returns>
        public static bool CheckData(string[] documents, int? count)
        {
            var isValid = false;
            if (documents.Length != 3 || count > 1 || documents[1] != "vs" && documents[1] != "VS")
            {
                Console.Clear();
                Console.WriteLine("Wrong format.\n");
                isValid = false;
            }
            else
                isValid = CheckCharacters(documents[0]) ? CheckCharacters(documents[2]) ? true : false : false;

            return isValid;
        }

        /// <summary>
        /// Método para comprobar los caracteres de un documento
        /// </summary>
        /// <param name="document"></param>
        /// <returns>Devuelve un bool para saber si todo es correcto o no</returns>
        public static bool CheckCharacters(string document)
        {
            for (int i = 0; i < document.Length; i++)
            {
                var doc = Char.ToUpper(document[i]);
                if (doc != 'K' && doc != 'N' && doc != 'V' && doc != '#')
                {
                    Console.Clear();
                    Console.WriteLine(String.Format("Wrong characters in document '{0}'.\n", document));
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Método cuya función es la suma de los caracteres de un documento
        /// </summary>
        /// <param name="document"></param>
        /// <returns>devuelve el resultado de la suma</returns>
        public static int AddPoints(string document)
        {
            var addition = 0;
            document = document.ToUpper();
            //Si el documento contiene una K, reemplazaremos la/s V en caso de que tenga/n
            if (document.Contains("K"))
                document = document.Replace("V", String.Empty);

            //Realizamos la suma
            for (int i = 0; i < document.Length; i++)
                addition += values[document[i]];

            return addition;
        }

        /// <summary>
        /// Método cuya función es la de cambiar # por el caracter correspondiente para ganar
        /// </summary>
        /// <param name="document"></param>
        /// <param name="sum"></param>
        /// <returns>Devuelve el caracter</returns>
        public static string ChangeCharacter(string document, int sum)
        {
            var character = String.Empty;
            //Sumamos los puntos actuales del documento que contiene #
            var addition = AddPoints(document);
            if(sum >= addition)
            {
                //Cuando la suma del documento con # supere a la suma del documento sin #, agregaremos el caracter correcto
                if (addition + 1 > sum && !document.ToUpper().Contains("K"))
                    character = "V";
                else if (addition + 2 > sum)
                    character = "N";
                else if (addition + 5 > sum)
                    character = "K";
                //Se puede dar el caso en que sea imposible ganar para el documento con #, por ejemplo: KKK vs K#N
                else
                    Console.WriteLine("In this case, it is impossible for the document with # to win.");
            }

            return character;
        }
    }
}